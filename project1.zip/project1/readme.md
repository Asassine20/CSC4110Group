## Installation

Install the following libraries using the below commands if you do not aleady have them installed:

pip install python-dotenv
pip install pandas
pip install validate-email-address


## Setup

You must add a .env file in the same directory of the csv file and main program

In the .env file, enter this:
PATH_TO_DATASET = 'relative_path_to_file'

example:
PATH_TO_DATASET = 'SWE/project1/bank_dataset.csv'

Note: .env variables are case sensitive, make sure you enter it exactly as it appears above


## Creating a new .csv file

If a new .csv file needs to be created, use the following website:
https://www.convertcsv.com/generate-test-data.htm

when adding keywords make sure to add the corresponding names that are
used in this project for them.

Example: the 'name' keyword generates a first name, so you would need to add a custom 'names' field called 'first_name' to make sure it stays in sync with this project. Order of the 'names' field must also match the order of the 'keywords' field
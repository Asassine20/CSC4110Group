import os
import re
from datetime import datetime
from dotenv import load_dotenv
import pandas as pd
from validate_email_address import validate_email

# Revision 1: 01/03/2024
## Begin Paul Shamoon 01/03/2024

class ModifyBankData:
    ''' Class to read, write, search, and delete data from a preexisting 
    dataset of bank account information stored in a csv file.
    '''

    def __init__(self) -> None:
        # Load environment variables from the .env file
        load_dotenv()

        # Access the variable 'PATH_TO_DATASET'
        path = os.getenv('PATH_TO_DATASET')

        # Store contents of .cvs file into self.data using the panda library
        self.data = pd.read_csv(path)

    def read(self):
        ''' Function to read a user specified amount of lines from the .csv file
        '''
        # Ask the user for the number of rows they want to read
        num_rows = input("\nEnter the number of rows to read(1-500), or press enter to read all rows: ")

        # Set pandas display options to show all rows since the default truncates them
        pd.set_option('display.max_rows', None)

        if num_rows:
            print(self.data.head(int(num_rows)))
        else:
            print(self.data)

    def write(self):
        ''' Function to write to a .csv file with all user specified fields
        '''
        fields = ['account_number', 'last_name', 'first_name', 'email', 'birthday', 'debit_card_number', 'account_balance']
        new_data = {}

        for field in fields:
            user_input = ''
            
            if field == 'account_number' or field == 'debit_card_number':
                required_length = 12 if field == 'account_number' else 16

                while len(user_input) != required_length or not user_input.isdigit():
                    user_input = input(f"Enter the {field} (must be {required_length} digits): ")

                    if len(user_input) != required_length or not user_input.isdigit():
                        print(f'Error, {field} is not {required_length} digits or contains non-numeric characters, try again')

            elif field == 'first_name' or field == 'last_name':
                while not user_input.isalpha():
                    user_input = input(f"Enter {field}: ")

                    if not user_input.isalpha():
                        print(f'Error, {field} should only contain alphabetic characters, try again')
          
            elif field == 'email':
                while not validate_email(user_input):
                    user_input = input("Enter your email address: ")

                    if not validate_email(user_input):
                        print("Error, invalid email format. Please enter a valid email address.")

            elif field == 'birthday':
                while True:
                    try:    
                        birthday_input = input(f"Enter {field} (must be in the format 00/00/0000): ")
                        birthday_date = datetime.strptime(birthday_input, "%m/%d/%Y")

                        # Format the date as "MM/DD/YYYY"
                        user_input = birthday_date.strftime("%m/%d/%Y")
                        break 
                    except ValueError:
                        print(f'Error, {field} must be in the format 9/1/2000, try again')

            else:
                while not re.match(r'^\$?\d+(\.\d{1,2})?$', user_input):
                    user_input = input(f"Enter {field} (e.g., $1200.30): ")

                    # Check if the input starts with a dollar sign, and add it if missing
                    if not user_input.startswith('$'):
                        user_input = '$' + user_input

                    if not re.match(r'^\$?\d+(\.\d{1,2})?$', user_input):
                        print(f'Error, {field} must be a valid money amount (e.g., $100.30), try again')
                
            # Add user input to specified field
            new_data[field] = user_input

        # Update the DataFrame with the new data
        self.data = self.data._append(new_data, ignore_index=True)

        # Write the changes to the .csv file
        self.data.to_csv(os.getenv('PATH_TO_DATASET'), index=False)
        print("Data written successfully.")

    def search(self):
        '''Function to search the .cvs file based on a user selected column and input
        '''
        # Columns that are in the .cvs file
        options = {
            '1': 'account_number',
            '2': 'last_name',
            '3': 'first_name',
            '4': 'email',
            '5': 'birthday',
            '6': 'debit_card_number',
            '7': 'account_balance'
        }

        while True:
            print("\nSearch Menu:")
            print("1. Search by Account Number")
            print("2. Search by Last Name")
            print("3. Search by First Name")
            print("4. Search by Email")
            print("5. Search by Birthday")
            print("6. Search by Debit Card Number")
            print("7. Search by Account Balance")
            print("8. Exit Search\n")

            # Get user's choice for column selection
            column_choice = input("Enter the number corresponding to the column you want to search (or enter 8 to exit): ")

            # Check if the user wants to exit
            if column_choice == '8':
                print("Exiting search.")
                return

            if column_choice in options:
                column_name = options[column_choice]

                # Get user's input for the value to search for
                search_value = input(f"Enter the value to search in the {column_name} column: ")

                # Perform the search in the user selected column based on entered search_value
                search_results = self.data[self.data[column_name].astype(str).str.contains(search_value, case=False)]

                if not search_results.empty:
                    print("Search results:\n", search_results)
                else:
                    print(f"No matching records found in the {column_name} column.")
            else:
                print("Invalid choice. Please enter a number between 1 and 8.")

    def delete(self):
        '''Function to delete a record based on the user inputed account number
        '''
        # Get the account number to delete
        account_number_to_delete = input("Enter the account number you want to delete: ")

        # Check if the account number exists in the .cvs file
        matching_rows = self.data[self.data['account_number'].astype(str) == account_number_to_delete]

        if not matching_rows.empty:
            # Check if there's only one matching record
            if len(matching_rows) == 1:
                index_to_delete = matching_rows.index[0]  # Use the actual index value
            else:
                # Display information about matching records
                print("Matching records:\n", matching_rows)
                
                # Choose which record to delete when there are multiple records with the same account number
                while True:
                    index_to_delete = int(input("Enter the index of the record you want to delete: "))
                    
                    if index_to_delete in matching_rows.index:
                        break
                    else:
                        print("Invalid index. Please enter a valid index.")

            # Get the first and last names belonging to the specified account number
            first_name = matching_rows.loc[index_to_delete]['first_name']
            last_name = matching_rows.loc[index_to_delete]['last_name']

            # Remove row from DataFrame
            self.data = self.data.drop(index_to_delete)

            # Write the changes to the .csv file
            self.data.to_csv(os.getenv('PATH_TO_DATASET'), index=False)

            print(f"Record with account number {account_number_to_delete} belonging to {first_name} {last_name} was deleted successfully.")
        else:
            print(f"No record found with account number {account_number_to_delete}.")

    def menu(self):
        ''' Function to display the options the user can perform 
        on the dataset and call its corresponding functions
        '''

        options = {
        '1': self.read,
        '2': self.write,
        '3': self.search,
        '4': self.delete,
        }

        while True:
            print("\nMenu:")
            print("1. Read Data")
            print("2. Write Data")
            print("3. Search Data")
            print("4. Delete Data")
            print("5. Quit")
            print('\n')


            choice = input("Enter your choice (1-4): ")

            if choice == '5':
                print("Exiting program. Goodbye!")
                break

            if choice in options:
                options[choice]()
            else:
                print("Invalid choice. Please enter a number between 1 and 5.")

# Initialize Modify_Bank_Data class
obj = ModifyBankData()
obj.menu()

# Revision 1: 02/03/2024
## End Paul Shamoon

# Group manager: Nicholas Accad / Project #1